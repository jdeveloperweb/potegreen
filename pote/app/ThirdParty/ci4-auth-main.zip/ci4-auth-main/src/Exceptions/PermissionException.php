<?php

namespace CI4\Auth\Exceptions;

class PermissionException extends \RuntimeException implements ExceptionInterface
{
}
