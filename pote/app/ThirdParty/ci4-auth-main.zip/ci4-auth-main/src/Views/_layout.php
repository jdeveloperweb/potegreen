<?= view('CI4\Auth\Views\_header') ?>

<main role="main" class="container" style="margin-top:80px;">

    <?= $this->renderSection('main') ?>

</main>
<!-- /.container -->

<?= view('CI4\Auth\Views\_footer') ?>